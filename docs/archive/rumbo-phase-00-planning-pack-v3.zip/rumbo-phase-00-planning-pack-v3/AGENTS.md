# AGENTS.md — Rumbo Platform Guidance

## Project identity

Rumbo is the internal codename for a suite of AI/nonprofit guidance tools. The external name may change. Do not hard-code public branding assumptions unless a phase explicitly asks for it.

The platform must support multiple tools, including at least:

- Sounds Like Us / guidance generation.
- Model evaluation.
- Future research/crawler/observatory tools.
- Public/embeddable widgets where there is a strong use case.

## Operating model

Use **Rumbo Guided Phases**:

- Work from the current phase document in `docs/development-phases/`.
- Do not expand scope just because nearby work seems useful.
- Future phases are provisional and may be revised after each phase closeout.
- Nothing may be silently dropped. Incomplete or blocked work must move to `docs/active-planning/deferred-work.md`, a named future phase, or be removed with a documented reason.

## Architecture guardrails

- Use a monorepo.
- Build a modular monolith now, with explicit seams for future distribution.
- Shared packages may be used by tools; shared packages must not depend on tool internals.
- Tool modules must not import each other directly unless an architecture decision explicitly permits it.
- Shared platform capabilities belong in packages, not in one tool.
- Keep centralized auth, orgs, admin, jobs, AI cost tracking, and billing readiness shared.

## Stack decisions

- Node: ESM only. Do not introduce CommonJS.
- Backend: Express.
- Frontend: server-rendered Twig by default; vanilla JS for simple interactivity; React for highly dynamic screens.
- Public anonymous brochure/marketing pages live in one WordPress site, not one brochure site per tool.
- CSS: SCSS, shared design system, no Bootstrap, no Tailwind-style framework.
- Icons: Lucide unless a documented decision changes this.
- Build: npm scripts, Vite where useful, no Gulp unless justified.
- Runtime: PM2 behind Apache proxy.
- DB: Prisma ORM with MySQL while using existing general-purpose EC2 servers; reconsider Postgres when infrastructure becomes Rumbo-specific.
- Python: Node calls Python via CLI/subprocess initially using JSON stdin/stdout/files.
- Storage: local EC2 filesystem through a storage adapter; keep S3 migration path open.

## Code organization expectations

Recommended starting structure:

```text
apps/
  platform-web/
  worker/
tools/
  sounds-like-us/
  model-eval/
packages/
  auth/
  config/
  db/
  design-system/
  ai/
  crawler/
  jobs/
  storage/
  python-bridge/
python/
  analysis/
docs/
.agent/
```

## CSS naming

Use moderate namespacing:

- `rj-` for shared platform/design-system classes.
- `slu-` for Sounds Like Us-specific classes.
- `meval-` for Model Eval-specific classes.

Avoid global generic classes like `.button`, `.card`, `.panel`, `.wrapper`.

## Documentation requirements

When code changes commands, config, architecture, data model, environment variables, or workflows, update the relevant docs in the same phase:

- `docs/reference/usage.md`
- `docs/project-charter/architecture.md`
- `docs/active-planning/decision-log.md`
- `docs/project-charter/data-model.md`
- `docs/project-charter/deployment.md`
- `docs/active-planning/roadmap.md`
- `docs/active-planning/deferred-work.md`

## Completion requirements

A phase is not complete until:

- Acceptance criteria pass.
- Commands work or are clearly documented as placeholders.
- Documentation reflects the current code.
- Deferred work is captured.
- The phase closeout is complete.
- The next phase has been reviewed and revised if needed.

## Documentation hygiene

Do not create new top-level files directly under `docs/` unless a phase file explicitly asks for them.

Use these locations:

- Stable project agreements: `docs/project-charter/`
- Active planning docs: `docs/active-planning/`
- Phase execution docs: `docs/development-phases/`
- Reference docs: `docs/reference/`
- Temporary or exploratory notes: `docs/working-notes/`
- Superseded material: `docs/archive/`
- Agent instructions: `.agent/`

Working notes are not source of truth. If a working note affects future work, promote the relevant information into `docs/project-charter/`, `docs/active-planning/`, `docs/reference/`, or the relevant phase file.

New agents should read `AGENTS.md`, then `docs/README.md`, then the current phase file. Do not tell agents to read all docs by default.
